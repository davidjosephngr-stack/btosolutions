import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  Bot,
  Check,
  ChevronRight,
  Clock3,
  Gauge,
  Layers3,
  Menu,
  MessageCircle,
  Network,
  Sparkles,
  Target,
  X,
  Zap,
} from "lucide-react";

const assets = {
  hero: "/manus-storage/bto-hero-human_caa0d0a6.jpg",
  audit: "/manus-storage/bto-audit-human_9960d306.jpg",
  leads: "/manus-storage/bto-leads-human_2b07f991.jpg",
  automation: "/manus-storage/bto-automation-human_6849b64b.jpg",
  strategy: "/manus-storage/bto-strategy-human_44a32ec7.jpg",
};

const services = [
  {
    number: "01",
    eyebrow: "AI ROI AUDIT",
    title: "Find exactly where AI pays for itself.",
    copy: "We map your operations, customer journey, and team structure to find the fastest, highest-value opportunities for AI.",
    image: assets.audit,
    icon: Target,
    points: ["Full operations review", "Prioritised opportunity map", "Costed 90-day roadmap"],
  },
  {
    number: "02",
    eyebrow: "LEAD GENERATION AI",
    title: "Turn every enquiry into a timely response.",
    copy: "AI responds, qualifies, and routes new leads while your team focuses on the conversations that actually need a human.",
    image: assets.leads,
    icon: MessageCircle,
    points: ["WhatsApp and web lead capture", "90-second first response", "CRM-ready lead handoff"],
  },
  {
    number: "03",
    eyebrow: "PROCESS AUTOMATION",
    title: "Replace repetitive work with reliable systems.",
    copy: "We connect the tools you already use so bookings, follow-ups, admin, and internal handoffs happen without constant chasing.",
    image: assets.automation,
    icon: Network,
    points: ["Workflow and CRM automation", "Booking and scheduling flows", "Human-in-the-loop controls"],
  },
  {
    number: "04",
    eyebrow: "AI STRATEGY",
    title: "Make AI a business advantage, not another subscription.",
    copy: "Get a practical operating model for adopting AI across your team, with clear priorities, guardrails, and measurable outcomes.",
    image: assets.strategy,
    icon: Layers3,
    points: ["AI adoption strategy", "Team enablement and playbooks", "Operational intelligence dashboard"],
  },
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [industry, setIndustry] = useState("Real Estate & Property");
  const [enquiries, setEnquiries] = useState(80);
  const [dealValue, setDealValue] = useState(450000);
  const [closeRate, setCloseRate] = useState(18);
  const [manualHours, setManualHours] = useState(18);
  const [hourlyCost, setHourlyCost] = useState(3500);
  const [submitted, setSubmitted] = useState(false);

  const monthlyLeak = useMemo(() => {
    const missedLeads = Math.max(1, enquiries * 0.14 * Math.max(0.25, 1 - closeRate / 100));
    const revenueLeak = missedLeads * dealValue * (closeRate / 100);
    const adminLeak = manualHours * 4.33 * hourlyCost;
    return Math.round(revenueLeak + adminLeak);
  }, [enquiries, dealValue, closeRate, manualHours, hourlyCost]);

  const formatNaira = (value: number) =>
    new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(value);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="topline"><span>AI ROI & OPERATIONAL INTELLIGENCE</span><span>LAGOS · NIGERIA · UNITED KINGDOM</span></div>
      <header className="site-header">
        <a className="brand" href="#top" onClick={closeMenu}>
          <span className="brand-mark">BTO</span>
          <span><strong>BTO SOLUTIONS LTD</strong><small>Build smarter. Operate lighter.</small></span>
        </a>
        <button className="mobile-toggle" aria-label="Toggle menu" onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X size={22} /> : <Menu size={22} />}</button>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          <a href="#solutions" onClick={closeMenu}>Solutions</a>
          <a href="#proof" onClick={closeMenu}>Outcomes</a>
          <a href="#calculator" onClick={closeMenu}>Calculator</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <button className="nav-cta" onClick={() => { closeMenu(); scrollToId("contact"); }}>Book a call <ArrowUpRight size={16} /></button>
        </nav>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-backdrop" style={{ backgroundImage: `url(${assets.hero})` }} />
          <div className="hero-overlay" />
          <div className="hero-grid">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-dot" /> AI systems for ambitious operators</div>
              <h1>Your business is already generating the data. <em>We turn it into leverage.</em></h1>
              <p className="hero-lede">BTO Solutions deploys practical AI systems that recover revenue, remove manual work, and give your team a clearer view of what is happening next.</p>
              <div className="hero-actions">
                <button className="button button-lime" onClick={() => scrollToId("calculator")}>Find your AI gap <ArrowUpRight size={18} /></button>
                <button className="text-link" onClick={() => scrollToId("solutions")}>See what we build <ChevronRight size={17} /></button>
              </div>
              <div className="credential-row"><span>UK No. 16326934</span><span>Nigeria RC 9452411</span><span>Audit delivered in 5 days</span></div>
            </div>
            <div className="hero-panel-wrap">
              <div className="hero-panel-label"><span className="status-pulse" /> LIVE OPERATIONAL VIEW</div>
              <div className="hero-panel">
                <div className="panel-top"><span>Revenue recovery signal</span><span className="panel-time">Last 30 days <ChevronRight size={13} /></span></div>
                <div className="panel-value">₦12.8m <span>+24.6%</span></div>
                <div className="sparkline"><span style={{ height: "28%" }} /><span style={{ height: "42%" }} /><span style={{ height: "35%" }} /><span style={{ height: "56%" }} /><span style={{ height: "51%" }} /><span style={{ height: "67%" }} /><span style={{ height: "62%" }} /><span style={{ height: "82%" }} /><span style={{ height: "76%" }} /><span style={{ height: "100%" }} /></div>
                <div className="panel-stat-grid"><div><small>NEW LEADS</small><strong>284</strong><span className="good">+18.2%</span></div><div><small>AI RESPONSE</small><strong>90s</strong><span className="good">-61% wait time</span></div><div><small>HOURS SAVED</small><strong>18/wk</strong><span className="good">+4.5 this month</span></div></div>
              </div>
              <div className="floating-chip chip-one"><Zap size={15} /> Lead routed <strong>just now</strong></div>
              <div className="floating-chip chip-two"><Check size={15} /> Workflow completed <strong>09:41</strong></div>
            </div>
          </div>
          <div className="hero-scroll"><span>Scroll to explore</span><span className="scroll-line" /></div>
        </section>

        <section className="proof-strip" id="proof">
          <div><strong>18+</strong><span>staff hours recovered<br />per week per engagement</span></div>
          <div><strong>90s</strong><span>average AI first-response<br />to new leads</span></div>
          <div><strong>100%</strong><span>audit fee credited back<br />on implementation</span></div>
          <div className="proof-note"><span className="tiny-label">BUILT FOR REAL OPERATIONS</span><p>Small teams in Lagos and the UK deserve systems that work as hard as they do.</p></div>
        </section>

        <section className="problem-section section-pad">
          <div className="section-intro split-intro"><div><span className="section-kicker">THE COST OF DOING NOTHING</span><h2>Most businesses are leaking revenue they cannot see.</h2></div><p>If you operate without practical AI systems, you are paying human hours for tasks machines handle in seconds. The loss is real. Our calculator turns your hours and enquiry volume into a number you can act on.</p></div>
          <div className="problem-grid">
            <article><div className="icon-disc"><Clock3 size={21} /></div><span className="card-index">01 / RESPONSE</span><h3>Slow replies quietly kill deals.</h3><p>When a new enquiry waits hours for a response, the buyer is already comparing you with a faster competitor.</p><div className="mini-metric"><strong>7%</strong><span>of companies answer a new lead within five minutes</span></div></article>
            <article><div className="icon-disc"><Bot size={21} /></div><span className="card-index">02 / OPERATIONS</span><h3>Manual admin eats your week.</h3><p>Bookings, follow-ups, spreadsheets, and WhatsApp coordination create hidden salary cost and constant context switching.</p><div className="mini-metric"><strong>18h</strong><span>can be recovered each week with the right workflows</span></div></article>
            <article><div className="icon-disc"><Gauge size={21} /></div><span className="card-index">03 / VISIBILITY</span><h3>You do not know your number.</h3><p>AI feels abstract until it is tied to your enquiry volume, average deal value, close rate, and staff cost.</p><div className="mini-metric"><strong>5 days</strong><span>to get a prioritised AI ROI audit from BTO</span></div></article>
          </div>
        </section>

        <section className="solutions-section section-pad" id="solutions">
          <div className="section-intro split-intro"><div><span className="section-kicker">WHAT WE BUILD</span><h2>Four practical systems. One measurable outcome.</h2></div><p>Every engagement ends with a system you own, a number you can measure, and a process your team can run without us.</p></div>
          <div className="services-grid">
            {services.map((service) => {
              const Icon = service.icon;
              return <article className="service-card" key={service.number}>
                <div className="service-image-wrap"><img src={service.image} alt={`People working together on ${service.eyebrow.toLowerCase()}`} /><span className="service-number">{service.number}</span><span className="image-tag"><Icon size={14} /> {service.eyebrow}</span></div>
                <div className="service-content"><div className="service-title-row"><h3>{service.title}</h3><ArrowUpRight size={21} /></div><p>{service.copy}</p><ul>{service.points.map((point) => <li key={point}><Check size={15} />{point}</li>)}</ul></div>
              </article>;
            })}
          </div>
        </section>

        <section className="transformation-section section-pad" id="about">
          <div className="section-intro"><span className="section-kicker">THE TRANSFORMATION</span><h2>Your operation before and after BTO.</h2><p>We do not sell AI theatre. We design the operating layer your business needs next.</p></div>
          <div className="before-after"><div className="state-card before"><div className="state-heading"><span>BEFORE</span><strong>Manual operations</strong></div><ul><li><span>01</span>Lead replies take hours or never happen.</li><li><span>02</span>WhatsApp coordination across multiple chats.</li><li><span>03</span>CRM updated manually from scattered inboxes.</li><li><span>04</span>No real-time visibility into pipeline or ops.</li></ul></div><div className="state-divider"><ArrowUpRight size={24} /></div><div className="state-card after"><div className="state-heading"><span>AFTER</span><strong>With BTO AI systems</strong></div><ul><li><span>01</span>AI responds to every lead in under 90 seconds.</li><li><span>02</span>Automated booking, scheduling, and follow-ups.</li><li><span>03</span>CRM auto-syncs. Every lead logged. Every time.</li><li><span>04</span>Live dashboard. Know your numbers in real time.</li></ul></div></div>
        </section>

        <section className="calculator-section section-pad" id="calculator">
          <div className="calculator-intro"><span className="section-kicker">FREE AI ROI CALCULATOR</span><h2>Find out what AI is costing you. Right now.</h2><p>Answer six questions about your operation. Get a directional estimate in less than two minutes.</p><div className="calculator-side-note"><Sparkles size={17} /><span>Your estimate is private. No sales pitch required.</span></div></div>
          <div className="calculator-card"><div className="calc-top"><div><span className="calc-label">YOUR BUSINESS SNAPSHOT</span><h3>Let’s run the numbers.</h3></div><div className="calc-step">01 <span>/ 06</span></div></div><div className="form-grid"><label>Industry<select value={industry} onChange={(event) => setIndustry(event.target.value)}><option>Real Estate & Property</option><option>Professional Services</option><option>Logistics & Supply Chain</option><option>Hospitality & Shortlet</option><option>Retail & E-commerce</option><option>Construction & Engineering</option></select></label><label>Enquiries or leads / month<input type="number" value={enquiries} onChange={(event) => setEnquiries(Number(event.target.value))} /></label><label>Average deal value (₦)<input type="number" value={dealValue} onChange={(event) => setDealValue(Number(event.target.value))} /></label><label>Close rate (%)<input type="number" value={closeRate} onChange={(event) => setCloseRate(Number(event.target.value))} /></label><label>Manual admin (hrs / week)<input type="number" value={manualHours} onChange={(event) => setManualHours(Number(event.target.value))} /></label><label>Staff cost (₦ / hour)<input type="number" value={hourlyCost} onChange={(event) => setHourlyCost(Number(event.target.value))} /></label></div><div className="estimate-row"><div><span className="calc-label">ESTIMATED MONTHLY LEAK</span><strong>{formatNaira(monthlyLeak)}</strong><small>A directional estimate based on the inputs above.</small></div><button className="button button-lime" onClick={() => setSubmitted(true)}>{submitted ? "Estimate updated" : "See my full leak estimate"} <ArrowUpRight size={17} /></button></div></div>
        </section>

        <section className="cta-section section-pad" id="contact"><div className="cta-orb orb-one" /><div className="cta-orb orb-two" /><div className="cta-inner"><span className="section-kicker">READY WHEN YOU ARE</span><h2>Turn the leak into a system.</h2><p>Book a free strategy call. We will look at your operation, identify the first high-return move, and tell you what it would take to build.</p><div className="cta-actions"><a className="button button-lime" href="mailto:contact@btosolutionsltd.com.ng?subject=Book a free AI strategy call">Book my free strategy call <ArrowUpRight size={18} /></a><a className="button button-ghost" href="https://wa.me/2347041507612" target="_blank" rel="noreferrer">Chat on WhatsApp <MessageCircle size={18} /></a></div><div className="contact-meta"><span>contact@btosolutionsltd.com.ng</span><span>+234 704 150 7612</span><span>Lagos · Nigeria · UK</span></div></div></section>
      </main>

      <footer className="site-footer"><div className="footer-brand"><span className="brand-mark">BTO</span><div><strong>BTO SOLUTIONS LTD</strong><p>AI ROI and operational intelligence for businesses ready to move.</p></div></div><div className="footer-links"><a href="#solutions">Solutions</a><a href="#proof">Outcomes</a><a href="#calculator">Calculator</a><a href="#contact">Contact</a></div><span className="footer-copy">© 2026 BTO Solutions Ltd</span></footer>
    </div>
  );
}
